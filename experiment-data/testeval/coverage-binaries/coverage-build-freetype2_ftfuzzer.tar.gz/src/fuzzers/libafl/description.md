# libafl

libafl fuzzer instance 
  - cmplog feature
  - persistent mode

Repository: [https://github.com/AFLplusplus/libafl/](https://github.com/AFLplusplus/libafl/)

[builder.Dockerfile](builder.Dockerfile)
[fuzzer.py](fuzzer.py)
[runner.Dockerfile](runner.Dockerfile)
