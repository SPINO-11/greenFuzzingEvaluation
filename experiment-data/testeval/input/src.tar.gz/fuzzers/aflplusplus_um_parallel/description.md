# aflplusplus UM (parallel)

Run aflplusplus over mutated code with parallel.

NOTE: This only works with C or C++ benchmarks.

[builder.Dockerfile](builder.Dockerfile)
[fuzzer.py](fuzzer.py)
[runner.Dockerfile](runner.Dockerfile)
