# aflplusplus UM (random)

Run aflplusplus over mutated code without UM prioritization. Randomly sample
list of generated mutants.

NOTE: This only works with C or C++ benchmarks.

[builder.Dockerfile](builder.Dockerfile)
[fuzzer.py](fuzzer.py)
[runner.Dockerfile](runner.Dockerfile)
